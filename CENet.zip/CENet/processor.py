from vis import tsne_vis

from sklearn.manifold import TSNE
from time import time
import torchvision
from torchvision import transforms
from torch.utils.data import DataLoader
import torch
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
# from modeling import build_model
from config import cfg
from model import make_model
from datasets import make_dataloader
import argparse
import os
from utils.logger import setup_logger
from torch.utils.data import Dataset
import glob
import os.path as osp
import re
from PIL import Image, ImageFile
import numpy as np
import scipy.io

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ReID Baseline Training")
    parser.add_argument(
        "--config_file", default="/data/luandong/data/ReID/TransReID_2_pretext_v2_joint_distill_v1/configs/Multi_domain_v2/vit_transreid.yml", help="path to config file", type=str
    )
    parser.add_argument("opts", help="Modify config options using the command-line", default=None,
                        nargs=argparse.REMAINDER)

    args = parser.parse_args()

    if args.config_file != "":
        cfg.merge_from_file(args.config_file)
    cfg.merge_from_list(args.opts)
    cfg.freeze()

    output_dir = cfg.OUTPUT_DIR
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)

    logger = setup_logger("transreid", output_dir, if_train=False)
    logger.info(args)

    if args.config_file != "":
        logger.info("Loaded configuration file {}".format(args.config_file))
        with open(args.config_file, 'r') as cf:
            config_str = "\n" + cf.read()
            logger.info(config_str)
    logger.info("Running with config:\n{}".format(cfg))

    os.environ['CUDA_VISIBLE_DEVICES'] = '2'#cfg.MODEL.DEVICE_ID


    # Initialize lists to store features and labels
    all_features = []
    all_features_rgb = []
    all_features_nir = []
    all_features_tir = []
    all_labels = []


    result = scipy.io.loadmat('pytorch_CENet_result.mat')
    query_feature = torch.FloatTensor(result['query_f'])
    query_cam = result['query_cam'][0]
    query_label = result['query_label'][0]
    gallery_feature = torch.FloatTensor(result['gallery_f'])
    gallery_cam = result['gallery_cam'][0]
    gallery_label = result['gallery_label'][0]
    print(gallery_feature.shape)
    sample_num = 1
    feat_ = gallery_feature.view(gallery_feature.shape[0], sample_num, -1).permute(1, 0, 2)
    print(feat_.shape)
    # Append features and labels to the respective lists
    labels = np.array(gallery_label).flatten()
    all_features.append(gallery_feature.cpu().numpy())
    #all_features_rgb.append(feat_[0].cpu().numpy())
    

    all_labels.append(labels)

    # Concatenate features and labels into numpy arrays
    all_features = np.concatenate(all_features, axis=0)
    #all_features_rgb = np.concatenate(all_features_rgb, axis=0)
    all_labels = np.concatenate(all_labels, axis=0)
    tsne_vis(all_features, all_labels, 360, 'all', mAP=20, config=cfg)
    #tsne_vis(all_features_rgb, all_labels, 360, 'rgb', mAP=20, config=cfg)

    torch.cuda.empty_cache()
