# encoding: utf-8
"""
@author:  sherlock
@contact: sherlockliao01@gmail.com
"""

import glob
import re

import os.path as osp

from .bases import BaseImageDataset
from collections import defaultdict
import pickle
class knight_c2c3_Syn_dark(BaseImageDataset):
    """
    Pretrain
    Reference:
    Zheng et al. Scalable Person Re-identification: A Benchmark. ICCV 2015.
    URL: http://www.liangzheng.org/Project/project_reid.html

    Dataset statistics:
    # identities: 1501 (+1 for background)
    # images: 12936 (train) + 3368 (query) + 15913 (gallery)
    """
    dataset_dir = ['Syn_dark_market_msmt','NightPerson_C23_MT']

    def __init__(self, root='', verbose=True, pid_begin = 0, **kwargs):
        super(knight_c2c3_Syn_dark, self).__init__()              
        #market_dir_day  = '/DATA/luandong/data/ReID_data/trans_reid_data/pretrain_dataset/market1501'
        self.dataset_dir_Syn = osp.join(root, self.dataset_dir[0])
        #print(self.dataset_dir_market)
        self.train_dir_Syn_train = osp.join(self.dataset_dir_Syn, 'bounding_box_train') 
        self.gallery_dir_Syn = osp.join(self.dataset_dir_Syn, 'bounding_box_test')
        self.query_dir_Syn = osp.join(self.dataset_dir_Syn, 'query') 

        self.train_dir_night600 = '/DATA/luandong/data/ReID_data/NightPerson_C23_MT/bounding_box_train'
        self.query_dir_night600 = '/DATA/luandong/data/ReID_data/NightPerson_C23_MT/query'
        self.gallery_dir_night600 = '/DATA/luandong/data/ReID_data/NightPerson_C23_MT/bounding_box_test'

        #self._check_before_run()
        self.pid_begin = pid_begin
        train_gen = self._process_dir_gen(self.train_dir_Syn_train, relabel=True)
        train_real = self._process_knight_dir(self.train_dir_night600, relabel=True)


        query_Syn = self._process_dir_gen(self.query_dir_Syn, relabel=False)
        gallery_Syn = self._process_dir_gen(self.gallery_dir_Syn, relabel=False)

        query_night600 = self._process_knight_dir(self.query_dir_night600, relabel=False)
        gallery_night600 = self._process_knight_dir(self.gallery_dir_night600, relabel=False)


        if verbose:
            print("=> Syn_Knight_c23_trainset dataset loaded")
            self.print_dataset_statistics(train_real, query_night600, gallery_night600)
            self.print_dataset_statistics_gen(train_gen, query_Syn, gallery_Syn)


        self.train_gen = train_gen
        self.train_real = train_real
        self.query_night600 = query_night600
        self.gallery_night600 = gallery_night600

        self.query_Syn = query_Syn
        self.gallery_Syn = gallery_Syn


        self.num_train_pids_real, self.num_train_imgs_real, self.num_train_cams_real, self.num_train_vids_real = self.get_imagedata_info(self.train_real)
        self.num_train_pids_gen, self.num_train_imgs_gen, self.num_train_cams_gen, self.num_train_vids_gen = self.get_imagedata_info_gen(self.train_gen)
        
        self.num_query_pids, self.num_query_imgs, self.num_query_cams, self.num_query_vids = self.get_imagedata_info(self.query_night600)
        self.num_gallery_pids, self.num_gallery_imgs, self.num_gallery_cams, self.num_gallery_vids = self.get_imagedata_info(self.gallery_night600)

    def _check_before_run(self):
        """Check if all files are available before going deeper"""
        if not osp.exists(self.dataset_dir[0]):
            raise RuntimeError("'{}' is not available".format(self.dataset_dir[0]))
        if not osp.exists(self.dataset_dir[1]):
            raise RuntimeError("'{}' is not available".format(self.dataset_dir[1]))
        if not osp.exists(self.query_night600):
            raise RuntimeError("'{}' is not available".format(self.query_night600))
        if not osp.exists(self.gallery_night600):
            raise RuntimeError("'{}' is not available".format(self.gallery_night600))


    def _process_knight_dir(self, dir_path, relabel=False):
        img_paths = glob.glob(osp.join(dir_path, '*.jpg'))
        pattern = re.compile(r'([-\d]+)_cam(\d)')

        pid_container = set()
        for img_path in sorted(img_paths):
            #print(img_path)
            pid, _ = map(int, pattern.search(img_path).groups())
            #print(pid)
            #if pid == -1: continue  # junk images are just ignored
            pid_container.add(pid)
        pid2label = {pid: label for label, pid in enumerate(pid_container)}
        dataset = []
        for img_path in sorted(img_paths):
            pid, camid = map(int, pattern.search(img_path).groups())
            #if pid == -1: continue  # junk images are just ignored
            # assert 0 <= pid <= 1501  # pid == 0 means background
            # assert 1 <= camid <= 6
            camid -= 1  # index starts from 0
            if relabel: pid = pid2label[pid]
            
            dataset.append((img_path, self.pid_begin + pid, camid, 1))
        return dataset



    def _process_dir_night600(self, dir_path, relabel=False):
        img_paths = glob.glob(osp.join(dir_path, '*.jpg'))
        pattern = re.compile(r'([-\d]+)_c(\d+)')

        pid_container = set()
        for img_path in sorted(img_paths):
            pid, _ = map(int, pattern.search(img_path).groups())
            if pid == -1: continue  # junk images are just ignored
            pid_container.add(pid)
        pid2label = {pid: label for label, pid in enumerate(pid_container)}
        dataset = []
        for img_path in sorted(img_paths):
            pid, camid = map(int, pattern.search(img_path).groups())
            if pid == -1: continue  # junk images are just ignored
            assert 0 <= pid <= 600  # pid == 0 means background
            assert 1 <= camid <= 8
            camid -= 1  # index starts from 0
            if relabel: pid = pid2label[pid]

            dataset.append((img_path, self.pid_begin + pid, camid, 1))
        return dataset


    def _process_dir_gen(self, dir_path, relabel=False):
        img_paths = glob.glob(osp.join(dir_path, '*.jpg'))
        pattern = re.compile(r'([-\d]+)_c(\d+)')

        pid_container = set()
        cid_container = set()
        for img_path in sorted(img_paths):
            img_name = img_path.split('/')[-1]
            img_name_new = img_name.split('_')[0] + '_' + img_name.split('_')[1]
            pid, cid = map(int, pattern.search(img_name_new).groups())
            if pid == -1: continue  # junk images are just ignored
            pid_container.add(pid)
            cid_container.add(cid)
        pid2label = {pid: label for label, pid in enumerate(pid_container)}
        cid2label = {cid: label for label, cid in enumerate(cid_container)}
        dataset = []
        for img_path in sorted(img_paths):
            img_name = img_path.split('/')[-1]
            img_name_new = img_name.split('_')[0] + '_' + img_name.split('_')[1]
            pid, camid = map(int, pattern.search(img_name_new).groups())
            #if pid == -1: continue  # junk images are just ignored
            assert 0 <= pid <= 4101+1501 # pid == 0 means background
            assert 1 <= camid <= 15+6+1
            img_path_gt = img_path.replace('Syn_dark_market_msmt','Syn_dark_market_msmt_GT')
            #camid -= 1  # index starts from 0
            camid = cid2label[camid]
            if relabel: 
                pid = pid2label[pid]

            dataset.append((img_path, img_path_gt, self.pid_begin + pid, camid, 1))
        return dataset
